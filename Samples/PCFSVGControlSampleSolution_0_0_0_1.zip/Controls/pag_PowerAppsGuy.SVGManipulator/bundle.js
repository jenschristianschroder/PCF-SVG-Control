var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./MeetingRoomsAvailability/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./MeetingRoomsAvailability/index.ts":
/*!*******************************************!*\
  !*** ./MeetingRoomsAvailability/index.ts ***!
  \*******************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nvar elemRecordId = \"elemRecId\";\n\nvar SVGManipulator =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function SVGManipulator() {\n    this.zoomLevel = 1;\n  }\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  SVGManipulator.prototype.init = function (context, notifyOutputChanged, state, container) {\n    this.randomString = Random.newString(); // Add control initialization code\n    // Need to track container resize so that control could get the available width. The available height won't be provided even this is true\n\n    context.mode.trackContainerResize(true);\n    context.parameters.dataSet.paging.setPageSize(100); // Create main table container div. \n\n    this.mainContainer = document.createElement(\"div\");\n    this.mainContainer.classList.add(\"main-container\"); // Create data table container div. \n\n    this.svgContainer = document.createElement(\"div\");\n    this.mainContainer.classList.add(\"svg-container\");\n    this.svgContainer.setAttribute(\"id\", this.randomString + \"svg-container\"); // Adding the main table and loadNextPage button created to the container DIV.\n\n    this.mainContainer.appendChild(this.svgContainer);\n    container.appendChild(this.mainContainer);\n    this._notifyOutputChanged = notifyOutputChanged;\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  SVGManipulator.prototype.updateView = function (context) {\n    // Add code to update control view\n    this.contextObj = context;\n\n    if (this.contextObj.parameters.svg != null) {\n      if (this.contextObj.parameters.svg.raw != null) {\n        this.svgContainer.innerHTML = this.contextObj.parameters.svg.raw.toString();\n        this.initSVG();\n      }\n    }\n\n    if (this.contextObj.parameters.zoomLevel != null) {\n      if (this.contextObj.parameters.zoomLevel.raw != null) {\n        this.zoomLevel = this.contextObj.parameters.zoomLevel.raw;\n      }\n    }\n\n    if (!this.contextObj.parameters.dataSet.loading) {\n      if (this.contextObj.parameters.dataSet.sortedRecordIds.length > 0) {\n        for (var _i = 0, _a = this.contextObj.parameters.dataSet.sortedRecordIds; _i < _a.length; _i++) {\n          var currentRecordId = _a[_i]; //alias workaround\n\n          var idColumn = this.contextObj.parameters.dataSet.columns.find(function (x) {\n            return x.alias === \"id\";\n          });\n          var idColumnName = idColumn == null ? \"id\" : idColumn.name;\n          var fillColumn = this.contextObj.parameters.dataSet.columns.find(function (x) {\n            return x.alias === \"fill\";\n          });\n          var fillColumnName = fillColumn == null ? \"fill\" : fillColumn.name;\n          var svgObjCollection = document.getElementsByClassName(this.contextObj.parameters.dataSet.records[currentRecordId].getFormattedValue(idColumnName).toLowerCase().replace(/\\s/g, \"\"));\n\n          for (var i = 0; i < svgObjCollection.length; i++) {\n            var svgObj = svgObjCollection[i];\n\n            if (svgObj != null) {\n              if (fillColumn != null) {\n                svgObj.style.fill = this.contextObj.parameters.dataSet.records[currentRecordId].getFormattedValue(fillColumnName);\n              } // Add onclick event to dom element\n\n\n              svgObj.addEventListener(\"click\", this.onElementClick.bind(this)); // Set the recordId on the dom element\n\n              svgObj.setAttribute(elemRecordId, currentRecordId);\n            }\n          }\n        }\n      }\n    } //reset zoom\n\n\n    this.reset();\n\n    if (this.contextObj.parameters.zoomToId != null) {\n      if (this.contextObj.parameters.zoomToId.raw != null) {\n        this.zoomToId = this.contextObj.parameters.zoomToId.raw.toString();\n\n        if (this.zoomToId != \"\") {\n          var svgElem = document.getElementById(this.zoomToId);\n\n          if (svgElem != null) {\n            //ZOOM\n            this.zoomToElement(this.zoomToId);\n          }\n        }\n      }\n    }\n  };\n  /**\r\n  * Row Click Event handler for the associated row when being clicked\r\n  * @param event\r\n  */\n\n\n  SVGManipulator.prototype.onElementClick = function (event) {\n    var elementRecordId = event.currentTarget.getAttribute(\"elemRecId\");\n\n    if (elementRecordId) {\n      var record = this.contextObj.parameters.dataSet.records[elementRecordId];\n      this.contextObj.parameters.dataSet.setSelectedRecordIds([elementRecordId]);\n      this.contextObj.parameters.dataSet.openDatasetItem(record.getNamedReference());\n\n      this._notifyOutputChanged();\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  SVGManipulator.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  SVGManipulator.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  SVGManipulator.prototype.initSVG = function () {\n    // the main SVG object and its current viewBox\n    this.svg = document.querySelector(\"#\" + this.randomString + \"svg-container svg\");\n    var viewbox = this.svg.getAttribute('viewBox');\n    this.vbox = viewbox.split(' ');\n    this.vbox[0] = parseFloat(this.vbox[0]);\n    this.vbox[1] = parseFloat(this.vbox[1]);\n    this.vbox[2] = parseFloat(this.vbox[2]);\n    this.vbox[3] = parseFloat(this.vbox[3]);\n  };\n\n  SVGManipulator.prototype.reset = function () {\n    this.svg.setAttribute(\"viewBox\", \"\" + this.vbox[0] + \" \" + this.vbox[1] + \" \" + this.vbox[2] + \" \" + this.vbox[3]);\n  };\n\n  SVGManipulator.prototype.zoomToElement = function (elementId) {\n    var element = this.svg.querySelector('#' + elementId);\n    var bbox = element.getBBox(); // the current center of the viewBox\n\n    var cx = this.vbox[0] + this.vbox[2] / 2;\n    var cy = this.vbox[1] + this.vbox[3] / 2; //SVGElement.prototype.getTransformToElement || function(toElement) { return toElement.getScreenCTM().inverse().multiply(this.getScreenCTM()); };\n\n    var matrix = element.getScreenCTM().inverse().multiply(this.svg.getScreenCTM()); // the new center\n\n    var newx = (bbox.x + bbox.width / 2) * matrix.a + matrix.e;\n    var newy = (bbox.y + bbox.height / 2) * matrix.d + matrix.f; // the corresponding top left corner in the current scale\n\n    var absolute_offset_x = this.vbox[0] + newx - cx;\n    var absolute_offset_y = this.vbox[1] + newy - cy; // the new scale\n\n    var scale = bbox.width * matrix.a / this.vbox[2] * (6 - this.zoomLevel);\n    var scaled_offset_x = absolute_offset_x + this.vbox[2] * (1 - scale) / 2;\n    var scaled_offset_y = absolute_offset_y + this.vbox[3] * (1 - scale) / 2;\n    var scaled_width = this.vbox[2] * scale;\n    var scaled_height = this.vbox[3] * scale;\n    this.svg.setAttribute(\"viewBox\", \"\" + scaled_offset_x + \" \" + scaled_offset_y + \" \" + scaled_width + \" \" + scaled_height);\n  };\n\n  SVGManipulator.prototype.setElementClassElement = function (elementId, classname) {\n    var element = this.svg.querySelector('#' + elementId);\n\n    if (element != null) {\n      element.classList.add(classname);\n    }\n  };\n\n  SVGManipulator.prototype.removeElementClassElement = function (elementId, classname) {\n    var element = this.svg.querySelector('#' + elementId);\n\n    if (element != null) {\n      element.classList.remove(classname);\n    }\n  };\n\n  return SVGManipulator;\n}();\n\nexports.SVGManipulator = SVGManipulator;\n\nvar Random =\n/** @class */\nfunction () {\n  function Random() {}\n\n  Random.newString = function () {\n    return 'axxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'.replace(/[xy]/g, function (c) {\n      var r = Math.random() * 16 | 0,\n          v = c == 'x' ? r : r & 0x3 | 0x8;\n      return v.toString(16);\n    });\n  };\n\n  return Random;\n}();\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./MeetingRoomsAvailability/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('PowerAppsGuy.SVGManipulator', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SVGManipulator);
} else {
	var PowerAppsGuy = PowerAppsGuy || {};
	PowerAppsGuy.SVGManipulator = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.SVGManipulator;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}